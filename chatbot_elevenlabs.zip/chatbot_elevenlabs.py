import customtkinter as ctk
from openai import OpenAI
import speech_recognition as sr
from elevenlabs import VoiceSettings
from elevenlabs.client import ElevenLabs
import threading
from datetime import datetime
from PIL import Image, ImageTk, ImageDraw
import requests
from io import BytesIO
import os
import subprocess
import glob
import pygame

OPENAI_KEY = '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'
ELEVENLABS_KEY = 'sk_2fd5d8109131602f2fcee5f06fad9bf85e4fe1097a57ca1a'

client = OpenAI(api_key=OPENAI_KEY)
eleven_client = ElevenLabs(api_key=ELEVENLABS_KEY)
recognizer = sr.Recognizer()
pygame.mixer.init()

class ChatbotApp:
    def __init__(self):
        self.window = ctk.CTk()
        self.window.title("Onryo AI Assistant")
        self.window.geometry("900x1000")
        ctk.set_appearance_mode("dark")
        
        self.is_listening = False
        self.speak_mode = True
        self.conversation_history = []
        self.ai_personality = "You are a helpful, friendly assistant."
        
        # ElevenLabs voice settings
        self.current_voice = "Rachel"  # Default voice
        self.voice_stability = 0.5
        self.voice_clarity = 0.75
        
        self.create_app_icon()
        self.setup_ui()
        
    def create_app_icon(self):
        try:
            if os.path.exists('custom_icon.png'):
                img = Image.open('custom_icon.png')
                img = img.resize((64, 64))
                img.save('onryo_icon.ico', format='ICO')
                self.window.iconbitmap('onryo_icon.ico')
                return
            img = Image.new('RGB', (64, 64), color='#1a1a2e')
            draw = ImageDraw.Draw(img)
            draw.ellipse([22, 15, 42, 35], fill='#16a085')
            draw.rectangle([28, 35, 36, 45], fill='#16a085')
            draw.line([20, 50, 44, 50], fill='#16a085', width=3)
            img.save('onryo_icon.ico', format='ICO')
            self.window.iconbitmap('onryo_icon.ico')
        except:
            pass
    
    def speak(self, text):
        """Ultra-realistic TTS with ElevenLabs"""
        try:
            audio = eleven_client.generate(
                text=text,
                voice=self.current_voice,
                model="eleven_monolingual_v1",
                voice_settings=VoiceSettings(
                    stability=self.voice_stability,
                    similarity_boost=self.voice_clarity,
                )
            )
            
            # Save and play
            with open("temp_speech.mp3", "wb") as f:
                for chunk in audio:
                    f.write(chunk)
            
            pygame.mixer.music.load("temp_speech.mp3")
            pygame.mixer.music.play()
            while pygame.mixer.music.get_busy():
                pygame.time.Clock().tick(10)
            pygame.mixer.music.unload()
            
            try:
                os.remove("temp_speech.mp3")
            except:
                pass
        except Exception as e:
            print(f"Speech error: {e}")
        
    def setup_ui(self):
        header = ctk.CTkFrame(self.window, fg_color="#1a1a2e")
        header.pack(fill="x", pady=10)
        ctk.CTkLabel(header, text="🎙️ ONRYO AI", font=("Arial", 28, "bold"), 
                    text_color="#16a085").pack(pady=10)
        
        self.tabview = ctk.CTkTabview(self.window, width=850, height=750)
        self.tabview.pack(pady=10, padx=20)
        
        self.tabview.add("💬 Chat")
        self.setup_chat_tab()
        
        self.tabview.add("⚙️ Settings")
        self.setup_settings_tab()
        
        self.tabview.add("🎨 Image Gen")
        self.setup_image_tab()
        
        self.tabview.add("📚 History")
        self.setup_history_tab()
        
    def setup_chat_tab(self):
        tab = self.tabview.tab("💬 Chat")
        
        self.chat_display = ctk.CTkTextbox(tab, width=800, height=450, font=("Arial", 14))
        self.chat_display.pack(pady=10)
        
        self.status_label = ctk.CTkLabel(tab, text="Ready!", font=("Arial", 13))
        self.status_label.pack(pady=5)
        
        btn_frame = ctk.CTkFrame(tab)
        btn_frame.pack(pady=10)
        
        self.listen_btn = ctk.CTkButton(btn_frame, text="🎤 Voice", command=self.toggle_listening, 
                                       width=110, height=45)
        self.listen_btn.pack(side="left", padx=5)
        
        self.speak_btn = ctk.CTkButton(btn_frame, text="🔊 ON", command=self.toggle_speech,
                                      width=100, height=45)
        self.speak_btn.pack(side="left", padx=5)
        
        ctk.CTkButton(btn_frame, text="Clear", command=self.clear_chat, width=100, height=45).pack(side="left", padx=5)
        ctk.CTkButton(btn_frame, text="💾 Save", command=self.save_chat, width=100, height=45).pack(side="left", padx=5)
        ctk.CTkButton(btn_frame, text="📁 Files", command=self.open_folder, width=100, height=45).pack(side="left", padx=5)
        
        input_frame = ctk.CTkFrame(tab)
        input_frame.pack(pady=15, fill="x", padx=20)
        
        self.text_input = ctk.CTkEntry(input_frame, placeholder_text="Type message...", font=("Arial", 15), height=50)
        self.text_input.pack(side="left", fill="x", expand=True, padx=5)
        self.text_input.bind("<Return>", self.send_text)
        
        ctk.CTkButton(input_frame, text="Send", command=self.send_text, width=120, height=50).pack(side="left", padx=5)
        
    def setup_settings_tab(self):
        tab = self.tabview.tab("⚙️ Settings")
        
        ctk.CTkLabel(tab, text="AI Personality", font=("Arial", 20, "bold")).pack(pady=20)
        
        presets = [
            ("🤝 Professional", "You are a professional, formal assistant."),
            ("😊 Friendly", "You are warm, friendly, and casual."),
            ("🧠 Expert", "You are highly knowledgeable and explain clearly."),
            ("😄 Funny", "You are witty and humorous."),
        ]
        
        preset_frame = ctk.CTkFrame(tab)
        preset_frame.pack(pady=10)
        
        for name, personality in presets:
            ctk.CTkButton(preset_frame, text=name, width=200,
                         command=lambda p=personality: self.set_personality(p)).pack(pady=3)
        
        ctk.CTkLabel(tab, text="\nCustom Personality:", font=("Arial", 14)).pack(pady=10)
        
        self.custom_personality = ctk.CTkTextbox(tab, width=700, height=120, font=("Arial", 13))
        self.custom_personality.pack(pady=10)
        self.custom_personality.insert("1.0", self.ai_personality)
        
        ctk.CTkButton(tab, text="Apply", command=self.apply_personality, width=200, height=40).pack(pady=10)
        
        # Voice Selection
        ctk.CTkLabel(tab, text="\n🎙️ Voice Selection (ElevenLabs):", font=("Arial", 16, "bold")).pack(pady=10)
        
        voice_frame = ctk.CTkFrame(tab)
        voice_frame.pack(pady=10)
        
        voices = [
            ("Rachel 🇺🇸 (Calm Female)", "Rachel"),
            ("Drew 🇺🇸 (Young Male)", "Drew"),
            ("Clyde 🇺🇸 (Middle-Aged Male)", "Clyde"),
            ("Bella 🇬🇧 (British Female)", "Bella"),
            ("Antoni 🇬🇧 (British Male)", "Antoni"),
            ("Elli 🇺🇸 (Energetic Female)", "Elli"),
            ("Josh 🇺🇸 (Deep Male)", "Josh"),
            ("Arnold 🇺🇸 (Strong Male)", "Arnold"),
            ("Charlotte 🇬🇧 (British Female)", "Charlotte"),
            ("Matilda 🇬🇧 (British Female)", "Matilda"),
        ]
        
        for display_name, voice_id in voices:
            ctk.CTkButton(voice_frame, text=display_name, width=280,
                         command=lambda v=voice_id: self.change_voice(v)).pack(pady=3)
        
        # Voice Customization
        ctk.CTkLabel(tab, text="\n🎚️ Voice Customization:", font=("Arial", 14)).pack(pady=10)
        
        # Stability slider
        stab_frame = ctk.CTkFrame(tab)
        stab_frame.pack(pady=5)
        ctk.CTkLabel(stab_frame, text="Stability (0=expressive, 1=stable):", width=250).pack(side="left", padx=5)
        self.stability_slider = ctk.CTkSlider(stab_frame, from_=0, to=1, width=300, number_of_steps=20)
        self.stability_slider.set(0.5)
        self.stability_slider.pack(side="left", padx=5)
        
        # Clarity slider
        clar_frame = ctk.CTkFrame(tab)
        clar_frame.pack(pady=5)
        ctk.CTkLabel(clar_frame, text="Clarity (0=original, 1=enhanced):", width=250).pack(side="left", padx=5)
        self.clarity_slider = ctk.CTkSlider(clar_frame, from_=0, to=1, width=300, number_of_steps=20)
        self.clarity_slider.set(0.75)
        self.clarity_slider.pack(side="left", padx=5)
        
        ctk.CTkButton(tab, text="Apply Voice Settings", command=self.apply_voice_settings,
                     width=200, height=40).pack(pady=15)
        
    def change_voice(self, voice_id):
        self.current_voice = voice_id
        self.status_label.configure(text=f"✅ Voice: {voice_id}")
    
    def apply_voice_settings(self):
        self.voice_stability = self.stability_slider.get()
        self.voice_clarity = self.clarity_slider.get()
        self.status_label.configure(text="✅ Voice settings updated!")
        
    def setup_image_tab(self):
        tab = self.tabview.tab("🎨 Image Gen")
        ctk.CTkLabel(tab, text="AI Image Generator", font=("Arial", 22, "bold")).pack(pady=20)
        
        self.image_prompt = ctk.CTkTextbox(tab, width=750, height=120)
        self.image_prompt.pack(pady=10)
        
        btn_frame = ctk.CTkFrame(tab)
        btn_frame.pack(pady=10)
        
        ctk.CTkButton(btn_frame, text="Generate", command=self.generate_image, width=150, height=50).pack(side="left", padx=5)
        ctk.CTkButton(btn_frame, text="Use as Icon", command=self.set_as_icon, width=150, height=50).pack(side="left", padx=5)
        
        self.image_status = ctk.CTkLabel(tab, text="")
        self.image_status.pack(pady=5)
        
        self.image_label = ctk.CTkLabel(tab, text="")
        self.image_label.pack(pady=10)
        
        self.last_generated_image = None
        
    def setup_history_tab(self):
        tab = self.tabview.tab("📚 History")
        ctk.CTkLabel(tab, text="Past Chats", font=("Arial", 22, "bold")).pack(pady=20)
        
        ctk.CTkButton(tab, text="🔄 Refresh", command=self.load_history, width=150, height=40).pack(pady=10)
        
        self.history_frame = ctk.CTkScrollableFrame(tab, width=750, height=350)
        self.history_frame.pack(pady=10)
        
        self.history_display = ctk.CTkTextbox(tab, width=750, height=180)
        self.history_display.pack(pady=10)
        
        self.load_history()
        
    def load_history(self):
        for widget in self.history_frame.winfo_children():
            widget.destroy()
        
        chats = glob.glob("chat_*.txt")
        chats.sort(reverse=True)
        
        if not chats:
            ctk.CTkLabel(self.history_frame, text="No saved chats").pack(pady=20)
            return
        
        for f in chats:
            try:
                date_part = f.replace("chat_", "").replace(".txt", "")
                date = datetime.strptime(date_part, "%Y%m%d_%H%M%S")
                display = date.strftime("%B %d, %Y at %I:%M %p")
            except:
                display = f
            
            btn_f = ctk.CTkFrame(self.history_frame)
            btn_f.pack(fill="x", pady=5, padx=10)
            
            ctk.CTkButton(btn_f, text=f"📄 {display}", command=lambda x=f: self.view_chat(x), 
                         width=550, height=35).pack(side="left", padx=5)
            ctk.CTkButton(btn_f, text="🗑️", command=lambda x=f: self.delete_chat(x), 
                         width=50, height=35, fg_color="red").pack(side="left")
    
    def view_chat(self, f):
        try:
            with open(f, 'r', encoding='utf-8') as file:
                self.history_display.delete("1.0", "end")
                self.history_display.insert("1.0", file.read())
        except:
            pass
    
    def delete_chat(self, f):
        try:
            os.remove(f)
            self.load_history()
            self.status_label.configure(text="🗑️ Deleted")
        except:
            pass
    
    def set_personality(self, p):
        self.ai_personality = p
        self.custom_personality.delete("1.0", "end")
        self.custom_personality.insert("1.0", p)
        self.status_label.configure(text="✅ Updated!")
    
    def apply_personality(self):
        self.ai_personality = self.custom_personality.get("1.0", "end").strip()
        self.status_label.configure(text="✅ Applied!")
        
    def generate_image(self):
        prompt = self.image_prompt.get("1.0", "end").strip()
        if not prompt:
            self.image_status.configure(text="❌ Enter description!")
            return
            
        self.image_status.configure(text="🎨 Generating...")
        self.window.update()
        
        try:
            response = client.images.generate(model="dall-e-3", prompt=prompt, size="1024x1024", n=1)
            img_data = requests.get(response.data[0].url).content
            img = Image.open(BytesIO(img_data))
            self.last_generated_image = img.copy()
            
            img.thumbnail((700, 700))
            photo = ImageTk.PhotoImage(img)
            self.image_label.configure(image=photo, text="")
            self.image_label.image = photo
            
            filename = f"image_{datetime.now().strftime('%Y%m%d_%H%M%S')}.png"
            self.last_generated_image.save(filename)
            self.image_status.configure(text=f"✅ {filename}")
        except Exception as e:
            self.image_status.configure(text=f"❌ {e}")
    
    def set_as_icon(self):
        if self.last_generated_image:
            try:
                icon = self.last_generated_image.resize((256, 256))
                icon.save('custom_icon.png')
                icon.save('onryo_icon.ico', format='ICO')
                self.image_status.configure(text="✅ Icon updated! Restart.")
            except Exception as e:
                self.image_status.configure(text=f"Error: {e}")
        else:
            self.image_status.configure(text="❌ Generate first!")
        
    def add_to_chat(self, text, sender):
        self.chat_display.insert("end", f"{sender}: {text}\n\n")
        self.chat_display.see("end")
        
    def clear_chat(self):
        self.is_listening = False
        self.listen_btn.configure(text="🎤 Voice")
        self.chat_display.delete("1.0", "end")
        self.conversation_history = []
        
    def send_text(self, event=None):
        text = self.text_input.get().strip()
        if not text:
            return
        self.text_input.delete(0, "end")
        self.add_to_chat(text, "You")
        self.get_response(text)
        
    def get_response(self, user_input):
        self.status_label.configure(text="🤔 Thinking...")
        self.conversation_history.append({"role": "user", "content": user_input})
        
        try:
            response = client.chat.completions.create(
                model="gpt-3.5-turbo",
                messages=[{"role": "system", "content": self.ai_personality}, *self.conversation_history]
            )
            
            ai_text = response.choices[0].message.content
            self.conversation_history.append({"role": "assistant", "content": ai_text})
            self.add_to_chat(ai_text, "AI")
            
            if self.speak_mode:
                self.status_label.configure(text="🔊 Speaking...")
                threading.Thread(target=lambda: self.speak(ai_text), daemon=True).start()
            
            self.status_label.configure(text="Ready!")
        except Exception as e:
            self.add_to_chat(f"Error: {e}", "System")
            
    def save_chat(self):
        content = self.chat_display.get("1.0", "end")
        if not content.strip():
            return
        filename = f"chat_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
        with open(filename, 'w', encoding='utf-8') as f:
            f.write(f"ONRYO AI\n{'='*50}\n{datetime.now()}\n\n{content}")
        self.status_label.configure(text="✅ Saved!")
    
    def open_folder(self):
        subprocess.Popen(f'explorer "{os.getcwd()}"')
        
    def toggle_speech(self):
        self.speak_mode = not self.speak_mode
        self.speak_btn.configure(text="🔊 ON" if self.speak_mode else "🔇 OFF")
        
    def toggle_listening(self):
        if not self.is_listening:
            self.is_listening = True
            self.listen_btn.configure(text="🛑 Stop")
            threading.Thread(target=self.listen_loop, daemon=True).start()
        else:
            self.is_listening = False
            self.listen_btn.configure(text="🎤 Voice")
            
    def listen_loop(self):
        while self.is_listening:
            try:
                with sr.Microphone() as source:
                    self.status_label.configure(text="🎤 Listening...")
                    recognizer.adjust_for_ambient_noise(source, 0.5)
                    audio = recognizer.listen(source, timeout=10, phrase_time_limit=30)
                    
                user_input = recognizer.recognize_google(audio, language='en-GB')
                self.add_to_chat(user_input, "You")
                
                if any(w in user_input.lower() for w in ['quit', 'exit', 'bye', 'stop']):
                    self.is_listening = False
                    self.listen_btn.configure(text="🎤 Voice")
                    break
                    
                self.get_response(user_input)
            except:
                continue
                
    def run(self):
        self.window.mainloop()

if __name__ == "__main__":
    app = ChatbotApp()
    app.run()